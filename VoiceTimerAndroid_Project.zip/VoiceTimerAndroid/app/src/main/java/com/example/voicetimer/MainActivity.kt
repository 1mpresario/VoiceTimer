package com.example.voicetimer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.util.TypedValue
import java.util.Locale

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var running = false
    private var startedAt = 0L
    private var elapsedBefore = 0L
    private lateinit var timerText: TextView
    private lateinit var statusText: TextView
    private lateinit var listenButton: Button

    private val tick = object : Runnable {
        override fun run() {
            renderTime()
            if (running) handler.postDelayed(this, 200)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.rgb(8, 8, 8)
        window.navigationBarColor = Color.rgb(8, 8, 8)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(Color.rgb(8, 8, 8))
        }
        statusText = TextView(this).apply {
            text = "Таймер остановлен"
            setTextColor(Color.LTGRAY); textSize = 16f; gravity = Gravity.CENTER
        }
        timerText = TextView(this).apply {
            text = "00:00:00"; setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 56f); gravity = Gravity.CENTER
            includeFontPadding = false
        }
        listenButton = Button(this).apply {
            text = "Включить голосовое управление"
            setOnClickListener { if (listening) stopListening() else startListening() }
        }
        val reset = Button(this).apply {
            text = "Сбросить таймер"
            setOnClickListener { stopTimer(); elapsedBefore = 0L; renderTime() }
        }
        val hint = TextView(this).apply {
            text = "Скажи «СТАРТ», чтобы запустить,\\nи «СТОП», чтобы остановить.\\n\\nОставь приложение открытым. Экран не будет гаснуть."
            setTextColor(Color.GRAY); textSize = 14f; gravity = Gravity.CENTER
        }
        layout.addView(statusText, LinearLayout.LayoutParams(-1, dp(42)))
        layout.addView(timerText, LinearLayout.LayoutParams(-1, dp(130)))
        layout.addView(listenButton, LinearLayout.LayoutParams(-1, dp(64)))
        layout.addView(reset, LinearLayout.LayoutParams(-1, dp(58)))
        layout.addView(hint, LinearLayout.LayoutParams(-1, dp(130)))
        setContentView(layout)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startTimer() {
        if (running) return
        startedAt = System.currentTimeMillis()
        running = true
        statusText.text = "Таймер работает"
        handler.removeCallbacks(tick); handler.post(tick)
    }

    private fun stopTimer() {
        if (!running) return
        elapsedBefore += System.currentTimeMillis() - startedAt
        running = false
        handler.removeCallbacks(tick)
        statusText.text = "Таймер остановлен"
        renderTime()
    }

    private fun renderTime() {
        val ms = elapsedBefore + if (running) System.currentTimeMillis() - startedAt else 0L
        val total = ms / 1000
        timerText.text = String.format(Locale.US, "%02d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60)
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.text = "На телефоне нет службы распознавания речи"; return
        }
        listening = true
        listenButton.text = "Выключить голосовое управление"
        statusText.text = "Слушаю команды «СТАРТ» и «СТОП»"
        createRecognizer()
    }

    private fun createRecognizer() {
        if (!listening) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { restartListening() }
                override fun onResults(results: Bundle?) {
                    val phrases = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                    phrases.forEach { phrase ->
                        val t = phrase.lowercase(Locale("ru", "RU")).replace('ё', 'е')
                        if (Regex("\\b(старт|стартуй|начать|запуск)\\b").containsMatchIn(t)) startTimer()
                        if (Regex("\\b(стоп|остановись|остановить|пауза)\\b").containsMatchIn(t)) stopTimer()
                    }
                    restartListening()
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { recognizer?.startListening(intent) } catch (_: Exception) { restartListening() }
    }

    private fun restartListening() {
        if (!listening) return
        handler.postDelayed({ if (listening) createRecognizer() }, 500)
    }

    private fun stopListening() {
        listening = false
        recognizer?.cancel(); recognizer?.destroy(); recognizer = null
        listenButton.text = "Включить голосовое управление"
        statusText.text = if (running) "Таймер работает" else "Таймер остановлен"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            statusText.text = "Микрофон разрешён. Нажми кнопку голосового управления."
        } else if (requestCode == 10) {
            statusText.text = "Для голосовых команд нужен доступ к микрофону."
        }
    }

    override fun onDestroy() {
        listening = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy(); recognizer = null
        super.onDestroy()
    }
}
